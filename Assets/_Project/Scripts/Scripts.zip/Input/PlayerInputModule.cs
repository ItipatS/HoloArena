using UnityEngine;
using UnityEngine.InputSystem;
using System.Collections.Generic;

public enum PlayerID { Player1, Player2 }

public class PlayerInputModule : MonoBehaviour, ICharacterModule
{
    [Header("Player Settings")]

     [SerializeField] private InputActionReference
     [SerializeField] private PlayerID _playerID;

    private Dictionary<string, KeyCode> keyMappings; // The mapping used by this instance.
    private Dictionary<string, bool> keyStates = new Dictionary<string, bool>();

    private InputBufferModule inputBuffer;
    private InputWindowCheckerModule inputWindowChecker = new InputWindowCheckerModule();

    public void Initialize(FighterController controller)
    {
        // Choose key mapping based on playerID.
        keyMappings = (playerID == PlayerID.Player1) ? keyMappingsPlayer1 : keyMappingsPlayer2;

        // Get the shared input buffer from the controller.
        inputBuffer = controller.InputBuffer;

        // Initialize keyStates for each key.
        foreach (var key in keyMappings.Keys)
        {
            keyStates[key] = false;
        }
    }

    public void Tick()
    {
        inputBuffer.Tick();

        List<string> pressedThisFrame = new List<string>();

        //Detect new key presses.
        foreach (var key in keyMappings.Keys)
        {
            bool wasPressed = keyStates[key];
            bool isPressed = Input.GetKey(keyMappings[key]);
            keyStates[key] = isPressed;

            if (isPressed && !wasPressed)
            {
                pressedThisFrame.Add(key);
            }
        }

        // Second pass: add new key presses to buffer and window checker.
        foreach (string action in pressedThisFrame)
        {
            inputBuffer.AddInput(action);
            inputWindowChecker.RecordInput(action);
        }
    }

    public bool IsKeyPressed(string action)
    {
        return keyMappings.ContainsKey(action) && Input.GetKeyDown(keyMappings[action]);
    }

    public bool IsKeyHeld(string action)
    {
        return keyMappings.ContainsKey(action) && Input.GetKey(keyMappings[action]);
    }

    public bool IsKeyReleased(string action)
    {
        return keyMappings.ContainsKey(action) && Input.GetKeyUp(keyMappings[action]);
    }

    public bool ConsumeBufferedInput(string action) => inputBuffer.ConsumeInput(action);

    public bool CheckInputInWindow(string action, float timeWindow) => inputWindowChecker.CheckInputInWindow(action, timeWindow);

    public void FixedTick()
    {
        inputWindowChecker.Cleanup();
    }
}
